// ==UserScript==
// @name         BNDL
// @namespace    http://tampermonkey.net/
// @version      0.21
// @description  try to take over the world!
// @author       ag0609
// @include      https://*.bookwalker.jp/*/viewer.html?*
// @run-at       document-end
// @grant        none
// ==/UserScript==

/*
known issue
-download image have black bar at bottom because of download bar appear when using Chrome
*/


(function() {
    var img, c, job;
    var cx, cy, cw,ch = 0;
    function chopCanvas(canvas, x, y, w, h) {
        x = x ? x : 0;
        y = y ? y : 0;
        w = w ? w : canvas.width;
        h = h ? h : canvas.height;
        console.log('chop: '+[x, y, w, h]);
        const context = canvas.getContext('2d');
        const imgData = context.getImageData(0,0,canvas.width,canvas.heightj);
        const croppedCanvas = document.createElement('canvas');
        croppedCanvas.width = w;
        croppedCanvas.height = h;
        const ctx = croppedCanvas.getContext('2d');
        //const newData = context.getImageData(x, y, w, h);
        const newData = context.getImageData(x,y,w,h);
        ctx.putImageData(newData, 0, 0);
        return croppedCanvas;
    }
    function trimCanvas(canvas, fuzz){
        console.log('trim');
        fuzz = fuzz ? fuzz : 13.33;
        const context = canvas.getContext('2d');
        const topLeft = {
            x: canvas.width,
            y: canvas.height,
            update(x,y){
                this.x = Math.min(this.x,x);
                this.y = Math.min(this.y,y);
            }
        };
        const bottomRight = {
            x: 0,
            y: 0,
            update(x,y){
                this.x = Math.max(this.x,x);
                this.y = Math.max(this.y,y);
            }
        };
        const imageData = context.getImageData(0,0,canvas.width,canvas.height);
        for(let x = 0; x < canvas.width; x++){
            for(let y = 0; y < canvas.height; y++){
                const red = imageData.data[((y * (canvas.width * 4)) + (x * 4))];
                const green = imageData.data[((y * (canvas.width * 4)) + (x * 4)) + 1];
                const blue = imageData.data[((y * (canvas.width * 4)) + (x * 4)) + 2];
                const alpha = imageData.data[((y * (canvas.width * 4)) + (x * 4)) + 3];
                if(alpha != 0 && ((red + green + blue)/3)/255 < (100-fuzz)/100){
                    topLeft.update(x,y);
                    bottomRight.update(x,y);
                }
            }
        }
        const width = bottomRight.x - topLeft.x;
        const height = bottomRight.y - topLeft.y;
        const croppedCanvas = document.createElement('canvas');
        const ctx = croppedCanvas.getContext('2d');
        [cx, cy, cw, ch] = [topLeft.x,topLeft.y,width,height];
        const newData = context.getImageData(cx,cy,cw,ch);
        console.log("tLx: "+ topLeft.x +", tLy: "+ topLeft.y +", bRx: "+ bottomRight.x +", h: "+ bottomRight.y);
        croppedCanvas.width = width;
        croppedCanvas.height = height;
        ctx.putImageData(newData,0,0);
        return croppedCanvas;
    }
    function fireKey(el, key) {
        key = key != null ? key : 34;
        var eventObj;
        if(document.createEventObject) {
            eventObj = document.createEventObject();
            eventObj.keyCode = key;
            el.fireEvent("onkeydown", eventObj);
        } else if(document.createEvent) {
            eventObj = document.createEvent("Events");
            eventObj.initEvent("keydown", true, true);
            eventObj.which = key;
            el.dispatchEvent(eventObj);
        }
        console.log("PAGE_DOWN fired");
    }
    function dataURItoBlob(dataURI) {
        var byteString;
        if (dataURI.split(',')[0].indexOf('base64') >= 0) byteString = atob(dataURI.split(',')[1]);
        else byteString = unescape(dataURI.split(',')[1]);
        var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
        var ia = new Uint8Array(byteString.length);
        for (var i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }
        return new Blob([ia], {type:mimeString});
    }
    function wait_for_canvas_loaded() {
        var canvas_containers = document.getElementsByClassName("currentScreen");
        if(!canvas_containers.length) return setTimeout(wait_for_canvas_loaded, 500);
        var canvas_list = canvas_containers[0].getElementsByTagName("canvas");
        if(!canvas_list.length) return setTimeout(wait_for_canvas_loaded, 500);
        c = canvas_list[0];
        create_btn();
    }
    function create_btn() {
        var btn = document.createElement('div');
        var btn_obj = document.createElement('button');
        btn_obj.type = 'button';
        btn_obj.id = 'abc1234';
        btn_obj.innerText = 'Save';
        btn_obj.onclick = saveFile;
        btn.style = 'width:100%;height:100%;top:0,0;background-color=rgb(0,0,0)';
        btn.appendChild(btn_obj);
        document.getElementsByClassName('padding')[0].appendChild(btn);
    }
    function saveFile() {
        var obj = document.getElementById('abc1234');
        if(job) {
            clearInterval(job);
            obj.innerText = "Save";
            return console.log('Stopped');
        }
        obj.innerText = "Wait";
        var fp = 0;
        job = setInterval(function() {
            var noTrim = 0;
            c = document.getElementsByClassName("currentScreen")[0].getElementsByTagName("canvas")[0];
            if(fp) noTrim = 1;
            else fp = 1;
            while(document.getElementById('zoomRatio').innerText != '200%') {
                console.log("Zoomrate: "+ document.getElementById('zoomRatio').innerText);
                document.getElementById("zoomInBtn").click();
            }
            var totp = (document.getElementById('pageSliderCounter').innerText).split('/')[1] * 1;
            var curp = (document.getElementById('pageSliderCounter').innerText).split('/')[0] * 1;
            console.log("Progress: "+ curp +"/"+ totp);
            obj.innerText = "Stop("+curp +"/"+ totp+")";
            var img;
            if(noTrim) img = chopCanvas(c, cx, cy, cw, ch);
            else img = trimCanvas(c);
            var blob = dataURItoBlob(img.toDataURL('image/jpeg'));
            var anchor = document.createElement("a");
            anchor.download = curp +".jpg";
            anchor.href = window.URL.createObjectURL(blob);
            anchor.target ="_blank";
            anchor.style.display = "none";
            document.body.appendChild(anchor);
            anchor.click();
            document.body.removeChild(anchor);
            //find some way to go next pages
            fireKey(document.getElementById('renderer'), 34);
            if(curp == totp) {
                clearInterval(job);
                obj.innerText = "Save";
                return console.log("completed");
            }
        },5000);
    }
    window.onLoad = setTimeout(wait_for_canvas_loaded, 5000);
})();